import React from 'react'
import NavBar from './NavComponent/NavBar.jsx'
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom'
import Product from './ProductComponent/Product.jsx'
import Cart from './ProductComponent/Cart.jsx'
import Update from './ProductComponent/Update.jsx'
function App() {
  return (

        <Router>
            <NavBar/>
            <Routes>
                <Route path='/' element={<Product/>}/>
                <Route path='/Cart' element={<Cart/>}/>
                <Route path='/Update/:id' element={<Update/>}/>
            </Routes>

        </Router>
  )
}

export default App