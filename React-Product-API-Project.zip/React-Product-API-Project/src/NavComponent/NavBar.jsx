import React from 'react'
import style from "./navbar.module.css"
import { Link } from 'react-router-dom'
import img from "../imgs/logo.png"
function NavBar() {
  return (
    <div>
        <div id={style.navbar}>
           <div id="logo"><img src={img} alt="" height={95} width={180}/></div>
           <div id={style.menu}>
              <li className="menu1"><Link className={style.link} to={"/"}>Product</Link></li>
              <li className="menu2"><Link className={style.link} to={"/Cart" }>Cart</Link></li>
           </div>
        </div>
    </div>
  )
}

export default NavBar