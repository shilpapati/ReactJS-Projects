import React, { useState } from 'react'
import style from "./ProComp.module.css"
import axiosInstance from './Axios';
import { useNavigate } from 'react-router-dom';

function Product() {
    let [pName, setPName] = useState("");
    let [pPrice, setPPrice] = useState("")
    let [pQnty, setPQnty] = useState("")
    let navi = useNavigate();
    let handleSubmit = (e) => {
        e.preventDefault()
        if(validate()){
            const payload={
                pName,
                pPrice,
                pQnty
            }
            axiosInstance.post("/posts", payload)
            navi("/Cart")
        }else{
            alert("All fields are required")
        }
    }
    let validate = () => {
        if (pName == "")
            return false
        if (pPrice == "")
            return false
        if (pQnty == "")
            return false
        else
            return true
    }
    return (
        <div>
            <form action="" className={style.form}  >
                <label htmlFor="ProductName">Product Name   :</label>
                <input type="text" name='ProductName'
                    onChange={(e) => { setPName(e.target.value) }} />  <br />  <br /><br />
                <label htmlFor="ProductPrice">Product Price :</label>
                <input type="text" name='ProductPrice'
                    onChange={(e) => { setPPrice(e.target.value) }} />  <br />  <br /><br />
                <label htmlFor="ProductQuantity">Product Quantity :</label>
                <input type="text" name='ProductQuantity'
                    onChange={(e) => { setPQnty(e.target.value) }} /> <br /> <br /><br />
                <button id={style.btn} onClick={handleSubmit} >  Add to Cart</button>
            </form>
        </div>
    )
}

export default Product