import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import axiosInstance from './Axios'
import styl from "./ProComp.module.css"

const Update = () => {
    let [pName, setName] = useState('')
    let [pPrice, setPrice] = useState('')
    let [pQnty, setQnty] = useState('')
    let nvgt = useNavigate();
    let { id } = useParams()

    useEffect(() => {
        let fetchdata = async () => {
            let { data } = await axiosInstance.get(`/posts/${id}`)
            setName(data.pName)
            setPrice(data.pPrice)
            setQnty(data.pQnty)
        }
        fetchdata()
    }, [])
    let handleUpdate = (e) => {
        e.preventDefault()
        const payload = {
            pName,
            pPrice,
            pQnty
        }
        axiosInstance.put(`/posts/${id}`, payload)
        nvgt('/Cart')
    }
    let handleCancel=()=>{
        nvgt('/Cart')
    }
    return (
        <div>
            <form action="" className={styl.update}>
                <label htmlFor='name'>Product Name</label>
                <input value={pName} type="text" id='name' name='name'
                    onChange={(e) => { setName(e.target.value) }} /> <br /> <br /> <br />
                <label htmlFor='pprice'>Product Price</label>
                <input value={pPrice} type="text" name='pprice' id='pprice'
                    onChange={(e) => { setPrice(e.target.value) }} /> <br /> <br /> <br />
                <label htmlFor='pqnty'>Product Quantity</label>
                <input value={pQnty} type="text" name='pqnty' id='pqnty'
                    onChange={(e) => { setQnty(e.target.value) }} /> <br /> <br /> <br />
                <div className={styl.butt}>
                    <button id={styl.pbtn} onClick={handleCancel}>Cancel</button>
                    <button id={styl.pbtn} onClick={handleUpdate}>Update</button>
                </div>
            </form>
        </div>
    )
}
export default Update