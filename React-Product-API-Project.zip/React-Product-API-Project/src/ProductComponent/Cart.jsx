import React, { useEffect, useState } from 'react'
import axiosInstance from './Axios'
import styl from "./ProComp.module.css"
import { useNavigate } from 'react-router-dom'

const Cart = () => {
    let [userdata,setUserdata]=useState([])
    let navig=useNavigate();
    useEffect(()=>{
        let fetchdata=async()=>{
            let {data}=await axiosInstance.get("/posts")
            setUserdata(data)
            console.log(data);
        }
        fetchdata()

    },[])
    let handlDelete=(id)=>{
        axiosInstance.delete(`/posts/${id}`)
        window.location.assign("/Cart")
    }
  return (
    <div id={styl.maindiv}>
        {userdata.map((x)=>{
           return(
            <div>
                <img src={`https://avatars.dicebear.com/v2/avataaars/${x.pname}.svg?options%5bmood%5d%5b%5d=happy`} alt="" height={170} width={170} />
                <h4>Product Name :{x.pName}</h4>
                <h4>Product Price :{x.pPrice}</h4>
                <h4>Product Quantity :{x.pQnty}</h4>
                <button id={styl.pbtn} onClick={()=>{navig(`/Update/${x.id}`)}}>Update</button>
                <button id={styl.pbtn} onClick={()=>{handlDelete(x.id)}}>Delete</button>
            </div>
           );
        })}
    </div>
  )
}

export default Cart